package com.example.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfiguration {

    @Autowired
    private JWTAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConf) throws Exception {
        return authConf.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .authorizeHttpRequests(auth -> auth

                        // Rutas publicas
                        .requestMatchers(HttpMethod.POST, "/login").permitAll()
                        .requestMatchers(HttpMethod.POST, "/tatuador").permitAll()
                        .requestMatchers(HttpMethod.POST, "/registro/cliente").permitAll()
                        .requestMatchers(HttpMethod.POST, "/registro/tatuador").permitAll()
                        .requestMatchers(HttpMethod.GET, "/disenios").permitAll()
                        .requestMatchers(HttpMethod.GET, "/disenios/*").permitAll()
                        .requestMatchers(HttpMethod.GET, "/etiquetas").permitAll()

                        // Rutas ADMINISTRADOR
                        .requestMatchers("/admin/**").hasAuthority("ADMINISTRADOR")
                        .requestMatchers(HttpMethod.POST, "/etiquetas").hasAuthority("ADMINISTRADOR")
                        .requestMatchers(HttpMethod.PUT, "/etiquetas/*").hasAuthority("ADMINISTRADOR")
                        .requestMatchers(HttpMethod.DELETE, "/etiquetas/*").hasAuthority("ADMINISTRADOR")

                        // Rutas TATUADOR
                        .requestMatchers(HttpMethod.POST, "/disenios").hasAuthority("TATUADOR")
                        .requestMatchers(HttpMethod.PUT, "/disenios/*").hasAuthority("TATUADOR")
                        .requestMatchers(HttpMethod.DELETE, "/disenios/*").hasAuthority("TATUADOR")

                        // Rutas CLIENTE
                        .requestMatchers(HttpMethod.POST, "/compras").hasAuthority("CLIENTE")
                        .requestMatchers(HttpMethod.POST, "/reclamaciones").hasAuthority("CLIENTE")
                        .requestMatchers(HttpMethod.POST, "/valoraciones").hasAuthority("CLIENTE")

                        .requestMatchers(HttpMethod.GET, "/actor/exportar").authenticated()
                        .requestMatchers(HttpMethod.DELETE, "/actor/perfil").authenticated()

                        // Rutas mensajes (cualquier actor autenticado)
                        .requestMatchers("/mensajes/**").authenticated()

                        // Rutas Swagger
                        .requestMatchers("/v3/api-docs/**").permitAll()
                        .requestMatchers("/swagger-ui.html", "/swagger-ui/**").permitAll()

                        // Resto requiere autenticacion
                        .anyRequest().authenticated()
                );

        http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(List.of("*"));
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(List.of("Authorization", "Content-Type"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);

        return source;
    }
}